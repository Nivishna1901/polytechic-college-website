const express = require('express');
const cors = require('cors');
const app = express();

// Allow requests from localhost:4200
app.use(cors({
    origin: 'http://localhost:4200',
    credentials: true   // if you need to include cookies in the requests
}));

// Other middleware and routes setup